package com.example.tp_flutter_produits

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
