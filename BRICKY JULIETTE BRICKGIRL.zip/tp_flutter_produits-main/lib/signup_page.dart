// signup_page.dart
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

class SignupPage extends StatelessWidget {
  final emailCtrl = TextEditingController();
  final passCtrl = TextEditingController();

  void signup(BuildContext context) async {
    await FirebaseAuth.instance.createUserWithEmailAndPassword(
      email: emailCtrl.text,
      password: passCtrl.text,
    );
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Inscription")),
      body: Column(
        children: [
          TextField(
            controller: emailCtrl,
            decoration: InputDecoration(labelText: "Email"),
          ),
          TextField(
            controller: passCtrl,
            decoration: InputDecoration(labelText: "Mot de passe"),
          ),
          ElevatedButton(
            onPressed: () => signup(context),
            child: Text("Créer"),
          ),
        ],
      ),
    );
  }
}
