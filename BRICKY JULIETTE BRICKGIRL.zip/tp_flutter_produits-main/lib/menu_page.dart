// menu_page.dart
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class MenuPage extends StatelessWidget {
  final nomCtrl = TextEditingController();
  final prixCtrl = TextEditingController();

  void addProduit() {
    FirebaseFirestore.instance.collection("produits").add({
      "nom": nomCtrl.text,
      "prix": prixCtrl.text,
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Menu Produits")),
      body: Column(
        children: [
          TextField(controller: nomCtrl, decoration: InputDecoration(labelText: "Nom du produit")),
          TextField(controller: prixCtrl, decoration: InputDecoration(labelText: "Prix")),
          ElevatedButton(onPressed: addProduit, child: Text("Ajouter")),

          Expanded(
            child: StreamBuilder(
              stream: FirebaseFirestore.instance.collection("produits").snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) return CircularProgressIndicator();
                return ListView(
                  children: snapshot.data!.docs.map<Widget>((doc) {
                    return ListTile(
                      title: Text(doc['nom']),
                      subtitle: Text("Prix: ${doc['prix']}"),
                    );
                  }).toList(),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
